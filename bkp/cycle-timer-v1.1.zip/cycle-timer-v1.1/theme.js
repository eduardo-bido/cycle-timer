// Toggle de tema (light/dark) simples e persistente.
(function () {
  var STORAGE_KEY = "cycle-timer-theme";

  function getTheme() {
    try {
      var saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved === "dark" || saved === "light") return saved;
    } catch (e) {}
    return "light";
  }

  function setTheme(theme) {
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {}
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    setTheme(theme);

    var btn = document.getElementById("theme-toggle");
    if (btn) {
      btn.setAttribute("data-theme", theme);
      btn.setAttribute("title", theme === "dark" ? "Modo claro" : "Modo escuro");
      btn.setAttribute("aria-label", theme === "dark" ? "Alternar para modo claro" : "Alternar para modo escuro");
    }
  }

  function toggleTheme() {
    var current = document.documentElement.getAttribute("data-theme") || getTheme();
    var next = current === "dark" ? "light" : "dark";
    applyTheme(next);
  }

  function initThemeToggle() {
    var btn = document.getElementById("theme-toggle");
    if (btn) {
      btn.addEventListener("click", toggleTheme);
    }
    applyTheme(getTheme());
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initThemeToggle);
  } else {
    initThemeToggle();
  }

  window.applyCycleTimerTheme = function (theme) {
    if (theme !== "dark" && theme !== "light") return;
    applyTheme(theme);
  };
})();

