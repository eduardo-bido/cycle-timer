// Página HELP: base de consulta desktop-first a partir de HELP_DATA.

(function () {
  var HELP_RENDERED = "data-help-rendered";
  var HELP_LANG = "data-help-lang";

  function getEntry(key) {
    return window.HELP_DATA && window.HELP_DATA[key] ? window.HELP_DATA[key] : null;
  }

  function escapeHtml(text) {
    if (text == null || text === "") return "";
    var div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  function tFn() {
    return window.I18N && window.I18N.t ? window.I18N.t : function (k) { return k; };
  }

  function renderHelpCard(key, t) {
    var e = getEntry(key);
    if (!e) return "";
    var html = '<article class="help-tile">';
    html += '<h3 class="help-tile-title">' + escapeHtml(e.label) + "</h3>";
    if (e.description) {
      html += '<p class="help-tile-desc">' + escapeHtml(e.description) + "</p>";
    }
    if (e.formula) {
      html += '<div class="help-tile-meta">' + escapeHtml(t("help_formula_label")) + "</div>";
      html += '<div class="help-tile-formula">' + escapeHtml(e.formula) + "</div>";
    }
    if (e.interpretation) {
      html += '<div class="help-tile-meta">' + escapeHtml(t("tooltip_interpretation")) + "</div>";
      html += '<p class="help-tile-interp">' + escapeHtml(e.interpretation) + "</p>";
    }
    html += "</article>";
    return html;
  }

  function renderRegion(regionId, titleKey, descKey, keys, t) {
    var html = '<section class="help-region" aria-labelledby="' + escapeHtml(regionId) + '">';
    html += '<header class="help-region-head">';
    html += '<h2 class="help-region-title" id="' + escapeHtml(regionId) + '">' + escapeHtml(t(titleKey)) + "</h2>";
    if (descKey) {
      html += '<p class="help-region-desc">' + escapeHtml(t(descKey)) + "</p>";
    }
    html += "</header>";
    html += '<div class="help-tile-grid">';
    for (var i = 0; i < keys.length; i++) {
      html += renderHelpCard(keys[i], t);
    }
    html += "</div></section>";
    return html;
  }

  function renderHelpToc(t) {
    var items = [
      { href: "#help-region-flow", key: "help_toc_item_flow" },
      { href: "#help-region-config", key: "help_toc_item_config" },
      { href: "#help-region-cycles", key: "help_toc_item_cycles" },
      { href: "#help-region-pallet", key: "help_toc_item_pallet" },
      { href: "#help-region-general", key: "help_toc_item_general" },
      { href: "#help-region-lines", key: "help_toc_item_lines" }
    ];
    var html = '<nav class="help-toc" aria-label="' + escapeHtml(t("help_toc_aria")) + '">';
    html += '<span class="help-toc-label">' + escapeHtml(t("help_toc_label")) + "</span>";
    html += '<ul class="help-toc-list">';
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      html += '<li class="help-toc-item">';
      html +=
        '<a class="help-toc-link" href="' +
        escapeHtml(it.href) +
        '">' +
        escapeHtml(t(it.key)) +
        "</a>";
      html += "</li>";
    }
    html += "</ul></nav>";
    return html;
  }

  function renderFlowDiagram(t) {
    var nodes = [
      { key: "productionBpm", tKey: "diagram_production" },
      { key: "gapBetweenBoxesS", tKey: "diagram_gap" },
      { key: "totalCycleTimePerPallet", tKey: "diagram_totalCycle" },
      { key: "totalStackingTimeRobotS", tKey: "diagram_totalStack" },
      { key: "robotOccupancyRate", tKey: "diagram_occupancy" },
      { key: "palletsPerHour", tKey: "diagram_palletsHour" }
    ];

    var html = '<section class="help-region help-region--flow" aria-labelledby="help-region-flow">';
    html += '<header class="help-region-head">';
    html += '<h2 class="help-region-title" id="help-region-flow">' + escapeHtml(t("help_flow")) + "</h2>";
    html += '<p class="help-region-desc">' + escapeHtml(t("help_flow_hint")) + "</p>";
    html += "</header>";
    html += '<div class="help-flow-rail" role="list">';
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      html += '<div class="help-flow-step" role="listitem">';
      html +=
        '<button type="button" class="help-flow-node help-node" data-help-key="' +
        escapeHtml(n.key) +
        '" title="' +
        escapeHtml(t("tooltip_helpTitle")) +
        '">';
      html += escapeHtml(t(n.tKey));
      html += "</button>";
      if (i < nodes.length - 1) {
        html += '<span class="help-flow-chevron" aria-hidden="true" role="presentation"></span>';
      }
      html += "</div>";
    }
    html += "</div></section>";
    return html;
  }

  function renderHelpPage() {
    var container = document.querySelector(".help-container");
    if (!container) return;
    var lang = window.APP_LANG || "pt";
    if (container.getAttribute(HELP_RENDERED) === "1" && container.getAttribute(HELP_LANG) === lang) {
      return;
    }

    var t = tFn();

    var keysConfig = [
      "robotName",
      "linesCount",
      "skuName",
      "productionBpm",
      "boxesPerLayer",
      "layersPerPallet",
      "picksPerLayer",
      "slipSheetBottom",
      "slipSheetBetweenLayers",
      "palletPick"
    ];

    var keysCycle = ["cycleTimePickS", "cycleTimeSlipSheetS", "cycleTimePalletS"];

    var keysPallet = [
      "gapBetweenBoxesS",
      "totalBoxesOnPallet",
      "picksPerPallet",
      "boxesPerCycle",
      "totalCyclesPerPallet",
      "totalCycleTimePicksS",
      "totalCycleTimeSlipSheetS",
      "totalCycleTimePalletsS",
      "totalCycleTimePerPallet",
      "totalStackingTimeRobotS"
    ];

    var keysGeneral = [
      "generalRobotOccupancyRate",
      "generalCyclesPerMinute",
      "generalRequiredCycleS",
      "generalAvailableCycleS",
      "generalMarginS",
      "generalChartComparison",
      "chartLegendRequired",
      "chartLegendRobot",
      "occupancyVisualStatus"
    ];

    var keysPerLine = [
      "robotOccupancyRate",
      "palletsPerHour",
      "averageCycleTimeS",
      "cyclesNumberPerMinute",
      "totalTimeOfPalletStackingS",
      "accumulationTimeToPalletExchangeS",
      "productNumberInSlipAccumulation",
      "cyclesToEmptySlipAccumulation",
      "productsNumberInPalletAccumulation",
      "cyclesToEmptyPalletAccumulation"
    ];

    var html = '<div class="help-surface">';
    html += '<header class="help-page-head">';
    html += '<p class="help-page-kicker">' + escapeHtml(t("help_page_kicker")) + "</p>";
    html += '<h1 class="help-page-title">' + escapeHtml(t("help_page_title")) + "</h1>";
    html += '<p class="help-page-lede">' + escapeHtml(t("help_page_intro")) + "</p>";
    html += "</header>";

    html += renderHelpToc(t);

    html += '<div class="help-body">';
    html += renderFlowDiagram(t);

    html += '<div class="help-columns">';
    html += '<div class="help-column help-column--inputs" id="help-zone-inputs">';
    html += '<p class="help-column-kicker">' + escapeHtml(t("help_column_inputs_kicker")) + "</p>";
    html += renderRegion("help-region-config", "help_region_config", "help_region_config_hint", keysConfig, t);
    html += renderRegion("help-region-cycles", "help_region_cycles", "help_region_cycles_hint", keysCycle, t);
    html += renderRegion("help-region-pallet", "help_region_pallet", "help_region_pallet_hint", keysPallet, t);
    html += "</div>";

    html += '<div class="help-column help-column--outputs" id="help-zone-outputs">';
    html += '<p class="help-column-kicker">' + escapeHtml(t("help_column_outputs_kicker")) + "</p>";
    html += renderRegion("help-region-general", "help_region_general", "help_region_general_hint", keysGeneral, t);
    html += renderRegion("help-region-lines", "help_region_lines", "help_region_lines_hint", keysPerLine, t);
    html += "</div>";

    html += "</div>";
    html += "</div>";

    html += "</div>";

    container.innerHTML = html;
    container.setAttribute(HELP_RENDERED, "1");
    container.setAttribute(HELP_LANG, lang);

    if (typeof initHelpTooltipsForNodes === "function") {
      initHelpTooltipsForNodes();
    }
  }

  window.renderHelpPage = function (force) {
    if (force) {
      var c = document.querySelector(".help-container");
      if (c) {
        c.removeAttribute(HELP_RENDERED);
      }
    }
    renderHelpPage();
  };
})();
