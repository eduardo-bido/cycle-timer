// i18n simples (PT-BR padrão) para toda a UI.
(function () {
  var STORAGE_KEY = "cycle-timer-lang";

  var I18N = {
    pt: {
      app_subtitle: "Ferramenta técnica de capacidade (paletização)",
      hero_title: "Ocupação do robô / Status",
      hero_occupancy_label: "Ocupação do robô",
      hero_status_label: "Status",
      hero_palletsHour: "Pallets/hora",
      hero_avgCycle: "Tempo médio de ciclo",

      outputs_prod_title: "Dados de produção",
      outputs_fixed_title: "Tempos fixos",
      outputs_results_title: "Resultados",
      outputs_slipBottom_short: "Slip sheet no fundo",
      outputs_slipBetween_short: "Slip sheet entre camadas",
      outputs_palletPick_short: "Pallet pick",

      res_totalBoxes: "Total de caixas no pallet",
      res_picksPallet: "Picks/pallet",
      res_gap: "Intervalo entre caixas (s)",
      res_boxesCycle: "Caixas/ciclo",
      res_totalCyclePallet: "Total de ciclos/pallet",
      res_cyclePicks: "Tempo total de ciclo/picks (s)",
      res_cycleSlip: "Tempo total de ciclo/slip sheet (s)",
      res_cyclePallets: "Tempo total de ciclo/pallets (s)",
      res_totalStacking: "Tempo total de stacking (s)",
      res_accum_exchange: "Tempo de acumulação até troca de pallet (s)",
      res_prod_slipAccum: "Qtd. produtos na acumulação/aplicação de slip sheet",
      res_cycles_emptySlip: "Qtd. ciclos para esvaziar acumulação (slip sheet)",
      res_prod_palletAccum: "Qtd. produtos na acumulação/troca de pallet",
      res_cycles_emptyPallet: "Qtd. ciclos para esvaziar a acumulação (pallet)",
      res_totalTimePalletStack: "Tempo total de montagem do pallet (s)",
      res_robotOcc: "Ocupação do robô",
      res_cyclesMin: "Ciclos/minuto",
      res_avgCycleS: "Tempo médio de ciclo (s)",
      res_palletsHour: "Pallets/hora",
      tabs_inputs: "ENTRADAS",
      tabs_outputs: "SAÍDAS",
      tabs_help: "AJUDA",

      sidebar_recipe: "Receita / SKU",
      sidebar_pallet: "Configuração de pallet",
      sidebar_picking: "Picking",
      sidebar_fixedTimes: "Tempos fixos",

      label_skuName: "SKU / Nome da receita",
      placeholder_skuName: "Ex.: SKU 123 - Linha CX 12kg",
      label_production: "Produção (cx/min)",

      label_boxesPerLayer: "Caixas por camada",
      label_layersPerPallet: "Camadas por pallet",
      label_picksPerLayer: "Qtd. picks (picks/camada)",
      label_palletPick: "Pallet pick (ciclos/pallet)",
      label_slipBottom: "Slip sheet no fundo (qtd)",
      label_slipBetween: "Slip sheet entre camadas (qtd)",

      label_robot: "Robô",
      placeholder_robot: "Ex.: KR240",
      label_cyclePick: "Tempo ciclo/pick (s)",
      label_cycleSlip: "Tempo ciclo/slip sheet (s)",
      label_cyclePallet: "Tempo ciclo/pallet (s)",

      output_title: "Resultados (tempo real)",
      output_lineKicker: "Linha analisada",
      output_lineLabel: "Linha",
      output_lineValue: "Receita atual",
      output_lineHint: "Preparado para múltiplas receitas/linhas.",

      output_primary_title: "Robô",
      output_primary_occ: "Ocupação",
      output_primary_cpm: "Ciclos/min",
      verdict: "Veredito",

      viz_title: "Visualização (capacidade)",
      chart_placeholder: "Gráfico (placeholder): requerido vs disponível / capacidade.",

      section_critical: "Números críticos",
      critical_required: "Cycle requerido (s)",
      critical_available: "Cycle disponível (s)",
      critical_margin: "Margem (req. − disp.)",

      section_performance: "Performance",
      perf_palletsHour: "Pallets/hora",
      perf_avgCycle: "Tempo médio de ciclo (s)",

      section_summary: "Resumo operacional",
      summary_boxesPallet: "Caixas por pallet",
      summary_totalPicks: "Total de picks",
      summary_totalLayers: "Total de camadas",

      section_feed: "Feed técnico (placeholder)",

      badge_input: "ENTRADA",
      badge_output: "SAÍDA",

      help_inputParams: "PARÂMETROS DE ENTRADA",
      help_flow: "Fluxo lógico do cálculo",
      help_flow_hint: "Da produção da linha até pallets/hora — passe o mouse nos nós para o mesmo texto dos tooltips.",
      help_metrics: "MÉTRICAS EXPLICADAS",
      help_page_kicker: "Documentação",
      help_page_title: "Referência da ferramenta",
      help_page_intro:
        "Consulta rápida dos conceitos, fórmulas e leituras usados nas entradas, no bloco Geral e nos cards por linha.",
      help_region_config: "Configuração, robô e receita",
      help_region_config_hint: "Identificação do cenário e parâmetros da planilha que alimentam os cálculos.",
      help_region_cycles: "Tempos de ciclo do robô",
      help_region_cycles_hint: "Pick, slip sheet e pallet — base para somar o tempo de execução.",
      help_region_pallet: "Pallet: intervalo, composição e tempos",
      help_region_pallet_hint: "Valores derivados desde o intervalo entre caixas até o tempo total do robô na linha.",
      help_region_general: "Bloco Geral e comparativo",
      help_region_general_hint: "KPIs consolidados, gráfico e cores de ocupação na coluna de saída.",
      help_region_lines: "Métricas por linha",
      help_region_lines_hint: "Indicadores e acúmulos exibidos em cada card de linha na saída.",

      help_toc_aria: "Índice da página de ajuda",
      help_toc_label: "Nesta página",
      help_toc_item_flow: "Fluxo do cálculo",
      help_toc_item_config: "Configuração e receita",
      help_toc_item_cycles: "Tempos de ciclo",
      help_toc_item_pallet: "Pallet e tempos",
      help_toc_item_general: "Bloco Geral e gráfico",
      help_toc_item_lines: "Métricas por linha",
      help_column_inputs_kicker: "Entrada — planilha e parâmetros",
      help_column_outputs_kicker: "Saída — consolidado e por linha",

      tooltip_formula: "Fórmula:",
      tooltip_interpretation: "Interpretação:",
      tooltip_helpTitle: "Ajuda",
      help_formula_label: "Fórmula",

      diagram_production: "Produção (cx/min)",
      diagram_gap: "Intervalo entre caixas",
      diagram_totalCycle: "Tempo total de ciclo / pallet",
      diagram_totalStack: "Tempo total de stacking",
      diagram_occupancy: "Ocupação do robô",
      diagram_palletsHour: "Pallets/hora",

      in_group_attendance: "Configuração do atendimento",
      in_group_recipes: "Receitas",
      in_robot_model: "Modelo do robô",
      in_lines_count: "Quantidade de linhas",
      line_1: "Linha 1",
      line_2: "Linha 2",
      line_3: "Linha 3",
      line_4: "Linha 4",
      line_5: "Linha 5",
      line_6: "Linha 6",

      sheet_col_name: "Nome da receita",
      sheet_col_boxesPerLayer: "Caixas por camada",
      sheet_col_layersPerPallet: "Camadas por pallet",
      sheet_col_picksPerLayer: "Qtd. picks por camada",
      sheet_col_palletPick: "Capturas de pallet",
      sheet_col_slipBottom: "Slip sheet na base",
      sheet_col_slipBetween: "Slip sheet entre camadas",

      sheet_expand: "Expandir planilha",
      sheet_close: "Fechar",
      sheet_addRow: "+ Nova receita",

      output_header_recipes_selection: "Seleção das receitas",
      output_general_title: "Geral",
      output_exec_occupancy: "Taxa de ocupação",
      output_exec_cycles_per_min: "Ciclos/min",
      output_exec_required_time: "Tempo necessário",
      output_exec_robot_time: "Tempo do robô",
      output_exec_margin: "Margem disponível",
      output_general_chart_placeholder: "Comparativo entre tempo necessário e tempo do robô por linha",
      output_aria_general_exec_kpis: "KPIs executivos do bloco geral",
      output_aria_general_chart: "Visualização comparativa",
      output_aria_lines_overview: "Análise individual por linha",

      output_chart_compare_lines: "Visualização comparativa entre linhas",
      output_chart_select_recipe_hint: "Selecione uma receita em pelo menos uma linha para visualizar a análise",
      output_chart_legend_required: "Necessário",
      output_chart_legend_robot_time: "Tempo do robô",
      output_line_prefix: "Linha",
      output_recipe_prefix: "Receita",
      output_line_select_recipe: "Selecione a receita",
      output_line_none_associated: "Nenhuma receita associada",
      output_line_header_sep: " | ",

      output_top_occupancy: "Taxa de ocupação",
      output_top_cycles_min: "Ciclos/min",
      output_top_required_time: "Tempo necessário",
      output_top_margin: "Margem disponível",

      output_row_recipe_name: "Nome da receita",
      output_row_production_bpm: "Produção (cx/min)",
      output_row_boxes_per_layer: "Caixas por camada",
      output_row_layers_per_pallet: "Camadas por pallet",
      output_row_quantity_of_picks: "Quantidade de picks",
      output_row_slip_bottom: "Slip sheet na base",
      output_row_slip_between: "Slip sheet entre camadas",
      output_row_pallet_pick: "Pallet pick",
      output_row_cycle_pick: "Tempo de ciclo/pick (s)",
      output_row_cycle_slip: "Tempo de ciclo/slip sheet (s)",
      output_row_cycle_pallet: "Tempo de ciclo/pallet (s)",
      output_row_total_boxes_pallet: "Caixas por pallet",
      output_row_picks_pallet: "Picks por pallet",
      output_row_gap_between_boxes: "Intervalo entre caixas (s)",
      output_row_boxes_per_cycle: "Caixas por ciclo",
      output_row_total_cycles_pallet: "Total de ciclos por pallet",
      output_row_total_time_picks: "Tempo total de picks (s)",
      output_row_total_time_slip: "Tempo total de slip sheet (s)",
      output_row_total_time_pallet: "Tempo total de pallet (s)",
      output_row_total_robot_time: "Tempo total do robô (s)",
      output_row_accum_time_exchange: "Tempo de acúmulo até a troca de pallet (s)",
      output_row_products_accum_slip: "Produtos acumulados (slip sheet)",
      output_row_cycles_clear_slip: "Ciclos para zerar acúmulo (slip sheet)",
      output_row_products_accum_pallet: "Produtos acumulados (pallet)",
      output_row_cycles_clear_pallet: "Ciclos para zerar acúmulo (pallet)",
      output_row_required_time: "Tempo necessário (s)",
      output_row_robot_occupancy: "Taxa de ocupação",
      output_row_cycles_per_minute: "Ciclos/min",
      output_row_average_cycle_time: "Tempo médio de ciclo (s)",
      output_row_pallets_hour: "Pallets/hora"
    },
    en: {
      app_subtitle: "Industrial palletizing capacity tool",
      hero_title: "Robot occupancy / Status",
      hero_occupancy_label: "Occupancy rate",
      hero_status_label: "Status",
      hero_palletsHour: "Pallets/hour",
      hero_avgCycle: "Average cycle time",

      outputs_prod_title: "Production data",
      outputs_fixed_title: "Fixed times",
      outputs_results_title: "Results",
      outputs_slipBottom_short: "Slip Sheet on the bottom",
      outputs_slipBetween_short: "Slip Sheet between layers",
      outputs_palletPick_short: "Pallet pick",

      res_totalBoxes: "Total boxes on the pallet",
      res_picksPallet: "Picks per pallet",
      res_gap: "Gap between boxes (s)",
      res_boxesCycle: "Boxes per cycle",
      res_totalCyclePallet: "Total cycles per pallet",
      res_cyclePicks: "Total pick cycle time (s)",
      res_cycleSlip: "Total slip sheet cycle time (s)",
      res_cyclePallets: "Total pallet cycle time (s)",
      res_totalStacking: "Total stacking time (s)",
      res_accum_exchange: "Accumulation time until pallet exchange (s)",
      res_prod_slipAccum: "Accumulated products during slip sheet",
      res_cycles_emptySlip: "Cycles to clear slip sheet accumulation",
      res_prod_palletAccum: "Accumulated products during pallet exchange",
      res_cycles_emptyPallet: "Cycles to clear pallet accumulation",
      res_totalTimePalletStack: "Total time of pallet stacking (s)",
      res_robotOcc: "Robot occupancy rate",
      res_cyclesMin: "Cycles/min",
      res_avgCycleS: "Average cycle time (s)",
      res_palletsHour: "Pallets/hour",
      tabs_inputs: "INPUTS",
      tabs_outputs: "OUTPUTS",
      tabs_help: "HELP",

      sidebar_recipe: "Recipe / SKU",
      sidebar_pallet: "Pallet setup",
      sidebar_picking: "Picking",
      sidebar_fixedTimes: "Fixed times",

      label_skuName: "SKU / Recipe name",
      placeholder_skuName: "Ex.: SKU 123 - Line CX 12kg",
      label_production: "Production (boxes/min)",

      label_boxesPerLayer: "Boxes per layer",
      label_layersPerPallet: "Layers per pallet",
      label_picksPerLayer: "Quantity of picks (picks/layer)",
      label_palletPick: "Pallet pick (cycles/pallet)",
      label_slipBottom: "Slip Sheet on the bottom (qty)",
      label_slipBetween: "Slip Sheet between layers (qty)",

      label_robot: "Robot",
      placeholder_robot: "Ex.: KR240",
      label_cyclePick: "Cycle time/pick (s)",
      label_cycleSlip: "Cycle time/slip sheet (s)",
      label_cyclePallet: "Cycle time/pallet (s)",

      output_title: "Results (real time)",
      output_lineKicker: "Analyzed line",
      output_lineLabel: "Line",
      output_lineValue: "Current recipe",
      output_lineHint: "Prepared for multiple recipes/lines.",

      output_primary_title: "Robot",
      output_primary_occ: "Occupancy",
      output_primary_cpm: "Cycles/min",
      verdict: "Verdict",

      viz_title: "Visualization (capacity)",
      chart_placeholder: "Chart placeholder: required vs available / capacity.",

      section_critical: "Critical numbers",
      critical_required: "Required cycle (s)",
      critical_available: "Available cycle (s)",
      critical_margin: "Margin (req. − avail.)",

      section_performance: "Performance",
      perf_palletsHour: "Pallets/hour",
      perf_avgCycle: "Average cycle time (s)",

      section_summary: "Operational summary",
      summary_boxesPallet: "Boxes per pallet",
      summary_totalPicks: "Total picks",
      summary_totalLayers: "Total layers",

      section_feed: "Technical feed (placeholder)",

      badge_input: "INPUT",
      badge_output: "OUTPUT",

      help_inputParams: "INPUT PARAMETERS",
      help_flow: "Calculation flow",
      help_flow_hint: "From line production to pallets/hour — hover nodes for the same text as in-app tooltips.",
      help_metrics: "METRICS EXPLAINED",
      help_page_kicker: "Documentation",
      help_page_title: "Tool reference",
      help_page_intro:
        "Quick lookup of concepts, formulas, and readings used in inputs, the General block, and per-line cards.",
      help_region_config: "Setup, robot, and recipe",
      help_region_config_hint: "Scenario identifiers and spreadsheet fields that feed the calculations.",
      help_region_cycles: "Robot cycle times",
      help_region_cycles_hint: "Pick, slip sheet, and pallet — the basis for total execution time.",
      help_region_pallet: "Pallet: spacing, composition, and times",
      help_region_pallet_hint: "Derived values from box spacing through total robot time on the line.",
      help_region_general: "General block and comparison chart",
      help_region_general_hint: "Consolidated KPIs, chart, and occupancy colors in the output column.",
      help_region_lines: "Per-line metrics",
      help_region_lines_hint: "Indicators and accumulations shown on each line card in the output.",

      help_toc_aria: "Help page table of contents",
      help_toc_label: "On this page",
      help_toc_item_flow: "Calculation flow",
      help_toc_item_config: "Setup and recipe",
      help_toc_item_cycles: "Cycle times",
      help_toc_item_pallet: "Pallet and times",
      help_toc_item_general: "General block and chart",
      help_toc_item_lines: "Per-line metrics",
      help_column_inputs_kicker: "Input — spreadsheet and parameters",
      help_column_outputs_kicker: "Output — consolidated and per line",

      tooltip_formula: "Formula:",
      tooltip_interpretation: "Interpretation:",
      tooltip_helpTitle: "Help",
      help_formula_label: "Formula",

      diagram_production: "Production (boxes/min)",
      diagram_gap: "Gap between boxes",
      diagram_totalCycle: "Total cycle time / pallet",
      diagram_totalStack: "Total stacking time",
      diagram_occupancy: "Robot occupancy rate",
      diagram_palletsHour: "Pallets/hour",

      in_group_attendance: "Service setup",
      in_group_recipes: "Recipes",
      in_robot_model: "Robot model",
      in_lines_count: "Line count",
      line_1: "Line 1",
      line_2: "Line 2",
      line_3: "Line 3",
      line_4: "Line 4",
      line_5: "Line 5",
      line_6: "Line 6",

      sheet_col_name: "Recipe name",
      sheet_col_boxesPerLayer: "Boxes per layer",
      sheet_col_layersPerPallet: "Layers per pallet",
      sheet_col_picksPerLayer: "Picks per layer",
      sheet_col_palletPick: "Pallet picks",
      sheet_col_slipBottom: "Bottom slip sheet",
      sheet_col_slipBetween: "Slip sheet between layers",

      sheet_expand: "Expand sheet",
      sheet_close: "Close",
      sheet_addRow: "+ New recipe",

      output_header_recipes_selection: "Recipe selection",
      output_general_title: "Overview",
      output_exec_occupancy: "Occupancy Rate",
      output_exec_cycles_per_min: "Cycles/min",
      output_exec_required_time: "Required Cycle Time",
      output_exec_robot_time: "Robot Cycle Time",
      output_exec_margin: "Available Time Margin",
      output_general_chart_placeholder: "Comparison between required cycle time and robot cycle time per line",
      output_aria_general_exec_kpis: "Executive KPIs from the general block",
      output_aria_general_chart: "Comparative view",
      output_aria_lines_overview: "Per-line individual analysis",

      output_chart_compare_lines: "Comparative view across lines",
      output_chart_select_recipe_hint: "Select a recipe in at least one line to view the analysis",
      output_chart_legend_required: "Required",
      output_chart_legend_robot_time: "Robot time",
      output_line_prefix: "Line",
      output_recipe_prefix: "Recipe",
      output_line_select_recipe: "Select recipe",
      output_line_none_associated: "No associated recipe",
      output_line_header_sep: " | ",

      output_top_occupancy: "Occupancy Rate",
      output_top_cycles_min: "Cycles/min",
      output_top_required_time: "Required Cycle Time",
      output_top_margin: "Available Time Margin",

      output_row_recipe_name: "Recipe name",
      output_row_production_bpm: "Production (boxes/min)",
      output_row_boxes_per_layer: "Boxes per layer",
      output_row_layers_per_pallet: "Layers per pallet",
      output_row_quantity_of_picks: "Quantity of picks",
      output_row_slip_bottom: "Slip sheet on the bottom",
      output_row_slip_between: "Slip sheet between layers",
      output_row_pallet_pick: "Pallet pick",
      output_row_cycle_pick: "Cycle time/pick (s)",
      output_row_cycle_slip: "Cycle time/slip sheet (s)",
      output_row_cycle_pallet: "Cycle time/pallet (s)",
      output_row_total_boxes_pallet: "Boxes per pallet",
      output_row_picks_pallet: "Picks per pallet",
      output_row_gap_between_boxes: "Gap between boxes (s)",
      output_row_boxes_per_cycle: "Boxes per cycle",
      output_row_total_cycles_pallet: "Total cycles per pallet",
      output_row_total_time_picks: "Total pick time (s)",
      output_row_total_time_slip: "Total slip sheet time (s)",
      output_row_total_time_pallet: "Total pallet time (s)",
      output_row_total_robot_time: "Total robot time (s)",
      output_row_accum_time_exchange: "Accumulation time until pallet exchange (s)",
      output_row_products_accum_slip: "Accumulated products (slip sheet)",
      output_row_cycles_clear_slip: "Cycles to clear accumulation (slip sheet)",
      output_row_products_accum_pallet: "Accumulated products (pallet)",
      output_row_cycles_clear_pallet: "Cycles to clear accumulation (pallet)",
      output_row_required_time: "Required Cycle Time (s)",
      output_row_robot_occupancy: "Occupancy Rate",
      output_row_cycles_per_minute: "Cycles/min",
      output_row_average_cycle_time: "Average cycle time (s)",
      output_row_pallets_hour: "Pallets/hour"
    }
  };

  function getLang() {
    try {
      var saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved === "en" || saved === "pt") return saved;
    } catch (e) {}
    return "pt";
  }

  function setLang(lang) {
    try {
      window.localStorage.setItem(STORAGE_KEY, lang);
    } catch (e) {}
  }

  function t(key) {
    var lang = window.APP_LANG || "pt";
    var dict = I18N[lang] || I18N.pt;
    return dict[key] || key;
  }

  function applyLanguage(lang) {
    window.APP_LANG = lang;
    setLang(lang);

    // Atualiza HELP_DATA apontando para o idioma ativo (se existir)
    if (window.HELP_DATA_BY_LANG) {
      window.HELP_DATA = window.HELP_DATA_BY_LANG[lang] || window.HELP_DATA_BY_LANG.pt;
    }

    // Atributo lang do documento
    document.documentElement.setAttribute("lang", lang === "pt" ? "pt-BR" : "en");

    // Texto via data-i18n
    var nodes = document.querySelectorAll("[data-i18n]");
    nodes.forEach(function (el) {
      var k = el.getAttribute("data-i18n");
      el.textContent = t(k);
    });

    // Placeholders via data-i18n-placeholder
    var ph = document.querySelectorAll("[data-i18n-placeholder]");
    ph.forEach(function (el) {
      var k = el.getAttribute("data-i18n-placeholder");
      el.setAttribute("placeholder", t(k));
    });

    // Tooltips title "Ajuda" → "Help"
    var helpTitles = document.querySelectorAll("[data-i18n-title]");
    helpTitles.forEach(function (el) {
      var k = el.getAttribute("data-i18n-title");
      el.setAttribute("title", t(k));
    });

    var ariaLabels = document.querySelectorAll("[data-i18n-aria-label]");
    ariaLabels.forEach(function (el) {
      var k = el.getAttribute("data-i18n-aria-label");
      el.setAttribute("aria-label", t(k));
    });

    // Re-render HELP page para refletir idioma
    if (typeof window.renderHelpPage === "function") {
      window.renderHelpPage(true);
    }

    if (typeof window.dispatchEvent === "function") {
      window.dispatchEvent(new CustomEvent("app-language-changed", { detail: { lang: lang } }));
    }
  }

  function toggleLanguage() {
    var next = (window.APP_LANG || getLang()) === "pt" ? "en" : "pt";
    applyLanguage(next);
  }

  function initLanguageToggle() {
    var btn = document.getElementById("lang-toggle");
    if (btn) {
      btn.addEventListener("click", toggleLanguage);
      btn.setAttribute("aria-label", "Trocar idioma");
    }
    applyLanguage(getLang());
  }

  window.I18N = { t: t, applyLanguage: applyLanguage, getLang: getLang };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLanguageToggle);
  } else {
    initLanguageToggle();
  }
})();

