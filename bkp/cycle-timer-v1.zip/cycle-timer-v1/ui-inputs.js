// Camada de UI da aba INPUTS: captura mudanças e envia para app.js

function initInputsUI(api) {
  var updateRecipe = api.updateRecipe;
  var updateRobotTimes = api.updateRobotTimes;

  function parseNumber(value) {
    if (value === null || value === undefined) return null;
    var trimmed = String(value).trim();
    // Se estiver vazio, assume 0 (ao invés de null).
    // Assim, o engine recebe um número e não depende de "—" por ausência.
    if (trimmed === "") return 0;
    // Aceita vírgula como separador decimal
    var normalized = trimmed.replace(",", ".");
    var n = parseFloat(normalized);
    return isNaN(n) ? null : n;
  }

  // ----- Campos de Receita -----
  var elNomeReceita = document.getElementById("recipe-nome");
  var elProductionBpm = document.getElementById("recipe-taxaEntradaCxMin");
  var elBoxesPerLayer = document.getElementById("recipe-produtosPorCamada");
  var elLayersPerPallet = document.getElementById("recipe-camadasPorPallet");
  var elPicksPerLayer = document.getElementById("recipe-capturasPorCamada");
  var elSlipSheetBottom = document.getElementById("recipe-slipSheetBottom");
  var elSlipSheetBetweenLayers = document.getElementById(
    "recipe-slipSheetBetweenLayers"
  );
  var elPalletPick = document.getElementById("recipe-capturasPallet");

  if (elNomeReceita) {
    elNomeReceita.addEventListener("input", function () {
      updateRecipe({ nomeReceita: elNomeReceita.value || "" });
    });
  }

  if (elProductionBpm) {
    elProductionBpm.addEventListener("input", function () {
      updateRecipe({ productionBpm: parseNumber(elProductionBpm.value) });
    });
  }

  if (elBoxesPerLayer) {
    elBoxesPerLayer.addEventListener("input", function () {
      updateRecipe({ boxesPerLayer: parseNumber(elBoxesPerLayer.value) });
    });
  }

  if (elLayersPerPallet) {
    elLayersPerPallet.addEventListener("input", function () {
      updateRecipe({ layersPerPallet: parseNumber(elLayersPerPallet.value) });
    });
  }

  if (elPicksPerLayer) {
    elPicksPerLayer.addEventListener("input", function () {
      updateRecipe({ picksPerLayer: parseNumber(elPicksPerLayer.value) });
    });
  }

  if (elSlipSheetBottom) {
    elSlipSheetBottom.addEventListener("input", function () {
      // Observação: a coluna visual "Capturas de pallet" está posicionada
      // no DOM sobre o input de id "recipe-slipSheetBottom".
      // Para que o Pallet pick (engine) use o valor do usuário corretamente,
      // mapeamos este input visual para o campo palletPick do estado.
      updateRecipe({ palletPick: parseNumber(elSlipSheetBottom.value) });
    });
  }

  if (elSlipSheetBetweenLayers) {
    elSlipSheetBetweenLayers.addEventListener("input", function () {
      updateRecipe({
        // Observação: o input de id "recipe-slipSheetBetweenLayers" corresponde
        // visualmente à coluna "Slip sheet na base".
        // Logo, este valor alimenta slipSheetBottom (engine).
        slipSheetBottom: parseNumber(elSlipSheetBetweenLayers.value)
      });
    });
  }

  if (elPalletPick) {
    elPalletPick.addEventListener("input", function () {
      // Observação: o input de id "recipe-capturasPallet" corresponde
      // visualmente à coluna "Slip sheet entre camadas".
      // Logo, este valor alimenta slipSheetBetweenLayers (engine).
      updateRecipe({ slipSheetBetweenLayers: parseNumber(elPalletPick.value) });
    });
  }

  // ----- Planilha: adicionar novas receitas (linhas extras não conectadas ao cálculo ainda) -----
  var elAddRow = document.getElementById("recipes-add-row");
  var elSheetBody = document.getElementById("recipes-sheet-body");
  var elAddRowOverlay = document.getElementById("recipes-add-row-overlay");
  var nextRow = 2;

  function buildNewRow(rowNumber) {
    var tr = document.createElement("tr");
    tr.className = "sheet-row";
    tr.setAttribute("data-row", String(rowNumber));

    function tdInput(type, inputmode, placeholder) {
      var td = document.createElement("td");
      var input = document.createElement("input");
      input.className = "sheet-cell";
      input.type = type;
      if (inputmode) input.setAttribute("inputmode", inputmode);
      if (placeholder) input.setAttribute("placeholder", placeholder);
      td.appendChild(input);
      return td;
    }

    // Ordem: Nome, Produção, Caixas/camada, Camadas/pallet, Picks/camada,
    // Slip sheet base, Slip sheet entre camadas, Capturas de pallet
    tr.appendChild(tdInput("text", "", "Ex.: SKU " + rowNumber));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));
    tr.appendChild(tdInput("number", "decimal", ""));

    var tdActions = document.createElement("td");
    tdActions.className = "sheet-cell-actions";
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "sheet-row-remove";
    btn.setAttribute("data-action", "remove-recipe-row");
    btn.setAttribute("aria-label", "Excluir receita");
    btn.textContent = "×";
    tdActions.appendChild(btn);
    tr.appendChild(tdActions);
    return tr;
  }

  function attachAddRow(btn) {
    if (!btn || !elSheetBody) return;
    btn.addEventListener("click", function () {
      elSheetBody.appendChild(buildNewRow(nextRow));
      nextRow += 1;
    });
  }

  attachAddRow(elAddRow);
  attachAddRow(elAddRowOverlay);

  // Remoção de receitas (com proteção para a linha 1: apenas limpa ao invés de remover)
  if (elSheetBody) {
    elSheetBody.addEventListener("click", function (e) {
      var target = e.target;
      if (!target || !target.closest) return;
      var btn = target.closest("button[data-action=\"remove-recipe-row\"]");
      if (!btn) return;
      var row = btn.closest("tr.sheet-row");
      if (!row) return;
      var rowId = row.getAttribute("data-row");
      if (rowId === "1") {
        var inputs = row.querySelectorAll("input");
        inputs.forEach(function (input) {
          input.value = "";
        });
        // Recalcula imediatamente com zeros quando a linha 1 é limpa.
        inputs.forEach(function (input) {
          input.dispatchEvent(new Event("input", { bubbles: true }));
        });
        return;
      }
      row.remove();
    });
  }

  // ----- Planilha: modo expandido (overlay) -----
  var elExpand = document.getElementById("recipes-expand");
  var elOverlay = document.getElementById("recipes-overlay");
  var elOverlayBody = document.getElementById("recipes-overlay-body");
  var elCollapse = document.getElementById("recipes-collapse");
  var elSheetWrap = document.querySelector("#inputs-view .sheet-wrap");

  var sheetOriginalParent = null;
  var sheetOriginalNextSibling = null;

  function openOverlay() {
    if (!elOverlay || !elOverlayBody || !elSheetWrap) return;
    if (elOverlay.classList.contains("is-open")) return;

    sheetOriginalParent = elSheetWrap.parentElement;
    sheetOriginalNextSibling = elSheetWrap.nextSibling;

    elOverlayBody.appendChild(elSheetWrap);
    elOverlay.classList.add("is-open");
    elOverlay.setAttribute("aria-hidden", "false");

    // foco inicial
    var firstInput = elOverlayBody.querySelector("input, select, textarea, button");
    if (firstInput) firstInput.focus();
  }

  function closeOverlay() {
    if (!elOverlay || !elOverlayBody || !elSheetWrap) return;
    if (!elOverlay.classList.contains("is-open")) return;

    if (sheetOriginalParent) {
      if (sheetOriginalNextSibling) {
        sheetOriginalParent.insertBefore(elSheetWrap, sheetOriginalNextSibling);
      } else {
        sheetOriginalParent.appendChild(elSheetWrap);
      }
    }

    elOverlay.classList.remove("is-open");
    elOverlay.setAttribute("aria-hidden", "true");

    if (elExpand) elExpand.focus();
  }

  if (elExpand) elExpand.addEventListener("click", openOverlay);
  if (elCollapse) elCollapse.addEventListener("click", closeOverlay);

  if (elOverlay) {
    elOverlay.addEventListener("click", function (e) {
      var t = e.target;
      if (t && t.getAttribute && t.getAttribute("data-overlay-close") === "1") {
        closeOverlay();
      }
    });
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeOverlay();
    }
  });

  // ----- Configuração do robô e tempos do robô -----
  var elRobotModel = document.getElementById("robot-model");
  var elLinesCount = document.getElementById("robot-lines-count");
  var elCycleTimePickS = document.getElementById("robot-cicloProdutoMs");
  var elCycleTimeSlipSheetS = document.getElementById("robot-cicloSlipsheetMs");
  var elCycleTimePalletS = document.getElementById("robot-cicloPalletMs");

  if (elRobotModel) {
    elRobotModel.addEventListener("change", function () {
      updateRobotTimes({ robo: elRobotModel.value || "" });
    });
  }

  function applyLinesVisibility() {
    var n = elLinesCount ? parseInt(elLinesCount.value, 10) : 1;
    if (!isFinite(n) || n < 1) n = 1;
    if (n > 6) n = 6;
    var fields = document.querySelectorAll("#inputs-view .robot-line-field[data-line]");
    var headers = document.querySelectorAll("#inputs-view .robot-line-header[data-line]");
    fields.forEach(function (field) {
      var line = parseInt(field.getAttribute("data-line"), 10);
      if (line <= n) {
        field.classList.add("is-visible");
      } else {
        field.classList.remove("is-visible");
      }
    });
    headers.forEach(function (header) {
      var line = parseInt(header.getAttribute("data-line"), 10);
      if (line <= n) {
        header.classList.add("is-visible");
      } else {
        header.classList.remove("is-visible");
      }
    });
  }

  if (elLinesCount) {
    elLinesCount.addEventListener("input", applyLinesVisibility);
    applyLinesVisibility();
  }

  if (elCycleTimePickS) {
    elCycleTimePickS.addEventListener("input", function () {
      updateRobotTimes({ cycleTimePickS: parseNumber(elCycleTimePickS.value) });
    });
  }

  if (elCycleTimeSlipSheetS) {
    elCycleTimeSlipSheetS.addEventListener("input", function () {
      updateRobotTimes({
        cycleTimeSlipSheetS: parseNumber(elCycleTimeSlipSheetS.value)
      });
    });
  }

  if (elCycleTimePalletS) {
    elCycleTimePalletS.addEventListener("input", function () {
      updateRobotTimes({
        cycleTimePalletS: parseNumber(elCycleTimePalletS.value)
      });
    });
  }
}

// Preenche os campos da aba INPUTS a partir do estado atual (usado na carga inicial)
function applyInputsFromState(recipe, robotTimes) {
  function setValue(id, value) {
    var el = document.getElementById(id);
    if (!el) return;
    if (value === null || value === undefined) {
      // Para inputs numéricos, preenche com 0; para texto, mantém vazio.
      if (el.type === "number") {
        el.value = "0";
      } else {
        el.value = "";
      }
    } else {
      el.value = String(value);
    }
  }

  if (recipe) {
    setValue("recipe-nome", recipe.nomeReceita);
    setValue("recipe-taxaEntradaCxMin", recipe.productionBpm);
    setValue("recipe-produtosPorCamada", recipe.boxesPerLayer);
    setValue("recipe-camadasPorPallet", recipe.layersPerPallet);
    setValue("recipe-capturasPorCamada", recipe.picksPerLayer);
    // Reaplica mapeamento visual->estado (para manter coerência com engine)
    setValue("recipe-slipSheetBottom", recipe.palletPick);
    setValue("recipe-slipSheetBetweenLayers", recipe.slipSheetBottom);
    setValue("recipe-capturasPallet", recipe.slipSheetBetweenLayers);
  }

  if (robotTimes) {
    setValue("robot-model", robotTimes.robo);
    setValue("robot-cicloProdutoMs", robotTimes.cycleTimePickS);
    setValue("robot-cicloSlipsheetMs", robotTimes.cycleTimeSlipSheetS);
    setValue("robot-cicloPalletMs", robotTimes.cycleTimePalletS);
  }
}


